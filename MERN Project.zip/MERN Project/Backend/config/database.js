// import the mongoose library

const mongoose = require('mongoose')

const connectDatabase =()=>{

    // establish connection to MongoDB using the DB_URI from environment variable

mongoose.connect(process.env.DB_URI, {
    useNewUrlParser:true,               // use the new URL parser
    useUnifiedTopology:true,            // use the new Server Discovery and Monitoring Engine 
    useCreateIndex: true                // ensure that mongoose uses createIndex() instead of ensureIndex() for index creation
    }).then((data)=>{
    
        // if the connection is successful, log a success message with the host information
    
        console.log(`Mongodb connected with server: ${data.connection.host}`) ; 
    
    }).catch((err)=>{
    
        // if there is error during the connection, log the error message
    
        console.log("Error connecting to MongoDB: " , err) ; 
    })
}

module.exports = connectDatabase ; 