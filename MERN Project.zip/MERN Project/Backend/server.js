// importing the express.js application that we've configured in the app.js file 

const app = require('./app')

// import the dotenv package to load environment variables from the config.env file 

const dotenv = require('dotenv') ; 

// import the 'connectDatabase' function for establishing a database connection

const connectDatabase = require("./config/database")

// load the configuration variables from the config.env file

dotenv.config({path:'Backend/config/config.env'})

// connecting to database 

connectDatabase()

// start the expressJS server and make it listen on the specified port 

app.listen(process.env.PORT,()=>{
    console.log(`Server is working on http://localhost:${process.env.PORT}`)
})