// import express library 

const express = require('express') ; 

// creates instance of the express application 

const app = express() ; 

// Middleware configuration --> this line configures express to use the express.json() middlware
// this middleware is used to parse incoming jSON data from HTTP requests

app.use(express.json())

// route imports 

const product = require("./routes/productRoute")

// using route

app.use("/api/v1", product) ; 

module.exports = app