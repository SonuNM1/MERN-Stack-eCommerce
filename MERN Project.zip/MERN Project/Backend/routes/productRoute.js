// importing the express library

const express = require('express') ; 

// importing the getAllProducts and createProduct function from the productController.js module 

const { getAllProducts, createProduct } = require('../controllers/productController');

// creating express router object 

const router = express.Router() ; 

// defining two routes using the 'router.route' method 

/* The first route is for handling HTTP GET requests to "/products." 
It specifies that when a GET request is made to "/products," the getAllProducts 
function from the productController should be executed. This route is used for 
retrieving a list of products. */

router.route("/products").get(getAllProducts) ; 

/* The second route is for handling HTTP POST requests to "/product/new." 
It specifies that when a POST request is made to "/product/new," the createProduct 
function from the productController should be executed. This route is used for 
creating a new product. */

router.route("/product/new").post(createProduct) ; 

module.exports = router ;  

/*
this code sets up routes for handling HTTP requests related to products 
using Express.js. 
It defines two routes: one for retrieving products and another 
for creating new products. */