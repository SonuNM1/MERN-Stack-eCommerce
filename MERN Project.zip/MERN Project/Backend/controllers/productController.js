// importing hte product model from the productModels file

const Product = require("../models/productModels")

// create Product 

// controller function to create a new product 

// Create product -- Admin 

exports.createProduct = async(req, res, next)=>{

    // create a new product in the database using data from the request body 

    const product = await Product.create(req.body) ; 

    // respond with the success status code 201 and the newly created product data in JSON format

    res.status(201).json({
        success:true, 
        product
    }) ; 

} ; 

// controller function to retrieve or get all products 

// 

exports.getAllProducts = async(req, res)=>{

    // respond with status code 200

    const products = await Product.find() ; 
    
    res.status(200).json({
        success:true,
        products
    })

}


/*

CONTROLLER FUNCTION: 

It receives an HTTP request (req) that contains data about the new product to be created. 
This data typically comes from a form submitted by a user on a website.

It uses the Product model (likely defined elsewhere in the code) to create a new product 
in the database. The product data is extracted from the req.body.

If the creation is successful, it sends an HTTP response (res) with a status code of 201 
(which means "Created") and a JSON object indicating success and containing information 
about the newly created product.

*/