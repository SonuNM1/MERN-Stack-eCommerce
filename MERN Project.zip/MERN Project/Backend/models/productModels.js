// import the mongoose library 

const mongoose = require("mongoose");

// define a Mongoose schema for a product --> database validation rules

const productSchema = new mongoose.Schema({

    // Product name 

    name: {
        type: String,
        required: [true, "Please enter product name"],
        trim: true
    },

    // Product description 

    description: {
        type: String,
        required: [true, "Please enter product description"]
    },

    // Product price 

    price: {
        type: Number,
        required: [true, "Please enter product price"],
        maxLength: [8, "Price cannot exceed 8 figure mark"]
    },

    // Product rating (default is 0)

    rating: {
        type: Number,
        default: 0
    },

    // Product images (an array of objects)

    images: [
        {
            public_id: {
                type: String,
                required: true
            },
            url: {
                type: String,
                required: true
            }
        }
    ],

    // Product category 

    category:{
        type:String, 
        required:[true,"Please enter product category"]
    },
    
    // Product stock (default is 1)

    stock:{
        type:Number, 
        required:[true, "Please enter product stock"],
        maxLength: [4, "Stock cannot exceed 4 characters"],
        default: 1
    },

    // Number of reviews (default is 0)

    noOfReviews:{
        type:Number, 
        default: 0
    }, 

    // Product review (an array of objects)

    reviews:[
        {
            name:{
                type:String,
                required:true,
            },
            rating:{
                type:Number, 
                required:true, 
            },
            comment:{
                type:String,
                required:true,
            }
        }
    ],

    // Product creation date (default is the current date and time)

    createdAt:{
        type:Date,
        default:Date.now
    }
})

// Export the product schema as a Mongoose model named "Product"

module.exports = mongoose.model("Product", productSchema) ; 